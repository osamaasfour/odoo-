# operation_logistics/views/__init__.py
# لا شيء هنا إذا كانت مجرد ملفات XML للـ views